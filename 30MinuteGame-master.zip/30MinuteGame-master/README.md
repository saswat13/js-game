30MinuteGame
============

30 Minutes to Your First Game from ByteArray.

See the show on Youtube at http://www.youtube.com/playlist?list=PLAgylfU8wrtsQWpm3NMCpEjV5fYyrC51p


